package com.boot.dao;

import java.util.List;
import com.boot.vo.MovieVO;
 
public interface MovieDAO {
    public List<MovieVO> selectMovie() throws Exception;
}